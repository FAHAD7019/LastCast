package com.lastcast;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Last Cast
 *
 * 1) Hold a fishing rod and run /lastcast  -> the rod is armed and set to 1 durability left.
 * 2) Cast the rod. After a short grace period, ANY other player who moves
 *    gets wiped: inventory, armor, offhand, ender chest, XP... like they just joined.
 * 3) The trap ends when you reel in (the rod breaks) or the bobber disappears.
 */
public class LastCastMod implements ModInitializer {

    /** Marker stored in the rod's custom_data component. */
    private static final String TAG = "lastcast_armed";

    /** Squared distance (blocks^2) that counts as "moved". 0.0001 = 0.01 blocks. */
    private static final double MOVE_EPSILON = 1.0E-4;

    /** Active traps, keyed by the caster's UUID. */
    private static final Map<UUID, Trap> TRAPS = new HashMap<>();

    /** Seconds victims get to freeze after the cast. Change with /lastcast grace <s>. */
    private static int graceSeconds = 3;

    private static final class Trap {
        int age = 0;
        final Map<UUID, double[]> lastPos = new HashMap<>();
        final Set<UUID> busted = new HashSet<>();
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("lastcast")
                        // No OP requirement: ordinary players can use the command.
                        .executes(ctx -> arm(ctx.getSource()))
                        .then(CommandManager.literal("give")
                                .executes(ctx -> giveRod(ctx.getSource())))
                        .then(CommandManager.literal("stop")
                                .executes(ctx -> stop(ctx.getSource())))
                        .then(CommandManager.literal("grace")
                                .then(CommandManager.argument("seconds", IntegerArgumentType.integer(0, 60))
                                        .executes(ctx -> {
                                            graceSeconds = IntegerArgumentType.getInteger(ctx, "seconds");
                                            ctx.getSource().sendFeedback(
                                                    () -> Text.literal("Grace period set to " + graceSeconds + "s"), false);
                                            return 1;
                                        })))));

        ServerTickEvents.END_SERVER_TICK.register(LastCastMod::tick);
    }

    // ------------------------------------------------------------------ commands

    private static int arm(ServerCommandSource source) throws CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();

        ItemStack rod = player.getMainHandStack();
        if (!rod.isOf(Items.FISHING_ROD)) {
            rod = player.getOffHandStack();
        }
        if (!rod.isOf(Items.FISHING_ROD)) {
            source.sendError(Text.literal("Hold a fishing rod first."));
            return 0;
        }

        configureRod(rod);

        source.sendFeedback(() -> Text.literal("Rod armed. Cast it to start."), false);
        return 1;
    }

    /** Gives the player a ready-to-use Last Cast rod with one durability left. */
    private static int giveRod(ServerCommandSource source) throws CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        ItemStack rod = new ItemStack(Items.FISHING_ROD);
        configureRod(rod);
        if (!player.getInventory().insertStack(rod)) {
            player.dropItem(rod, false);
        }
        source.sendFeedback(() -> Text.literal("You received a Last Cast fishing rod."), false);
        return 1;
    }

    private static void configureRod(ItemStack rod) {
        NbtCompound tag = new NbtCompound();
        tag.putBoolean(TAG, true);
        rod.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
        rod.set(DataComponentTypes.CUSTOM_NAME,
                Text.literal("Last Cast").formatted(Formatting.RED, Formatting.BOLD));
        rod.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        // Keep one durability point so reeling in breaks the rod and ends the trap.
        rod.setDamage(rod.getMaxDamage() - 1);
    }

    private static int stop(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        for (UUID id : new ArrayList<>(TRAPS.keySet())) {
            ServerPlayerEntity caster = server.getPlayerManager().getPlayer(id);
            if (caster != null && caster.fishHook != null) {
                caster.fishHook.discard();
            }
        }
        TRAPS.clear();
        source.sendFeedback(() -> Text.literal("All Last Cast traps stopped."), true);
        return 1;
    }

    // ------------------------------------------------------------------ game logic

    private static boolean isArmed(ItemStack stack) {
        if (!stack.isOf(Items.FISHING_ROD)) {
            return false;
        }
        NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        return data != null && data.copyNbt().contains(TAG);
    }

    private static boolean isCasting(ServerPlayerEntity player) {
        FishingBobberEntity hook = player.fishHook;
        return hook != null
                && !hook.isRemoved()
                && (isArmed(player.getMainHandStack()) || isArmed(player.getOffHandStack()));
    }

    private static void tick(MinecraftServer server) {
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();

        // 1) start / end traps
        for (ServerPlayerEntity caster : players) {
            boolean casting = isCasting(caster);
            Trap trap = TRAPS.get(caster.getUuid());

            if (casting && trap == null) {
                TRAPS.put(caster.getUuid(), new Trap());
            } else if (!casting && trap != null) {
                TRAPS.remove(caster.getUuid());
                server.getPlayerManager().broadcast(
                        Text.literal("The Last Cast is over.").formatted(Formatting.GREEN), false);
            }
        }

        // casters that disconnected
        TRAPS.keySet().removeIf(id -> server.getPlayerManager().getPlayer(id) == null);

        // 2) watch for movement
        for (Map.Entry<UUID, Trap> entry : TRAPS.entrySet()) {
            UUID casterId = entry.getKey();
            Trap trap = entry.getValue();
            trap.age++;
            boolean live = trap.age > graceSeconds * 20;

            for (ServerPlayerEntity p : players) {
                UUID id = p.getUuid();
                if (id.equals(casterId) || p.isSpectator() || !p.isAlive() || trap.busted.contains(id)) {
                    trap.lastPos.remove(id);
                    continue;
                }

                double x = p.getX();
                double y = p.getY();
                double z = p.getZ();
                double[] prev = trap.lastPos.get(id);

                if (live && prev != null) {
                    double dx = x - prev[0];
                    double dy = y - prev[1];
                    double dz = z - prev[2];
                    if (dx * dx + dy * dy + dz * dz > MOVE_EPSILON) {
                        trap.busted.add(id);
                        wipe(p);
                        server.getPlayerManager().broadcast(
                                Text.literal(p.getName().getString() + " moved and lost EVERYTHING!")
                                        .formatted(Formatting.RED, Formatting.BOLD), false);
                        continue;
                    }
                }
                trap.lastPos.put(id, new double[]{x, y, z});
            }
        }
    }

    /** Resets the player as if they had just joined the server. */
    private static void wipe(ServerPlayerEntity p) {
        p.closeHandledScreen();            // close an open ender chest / container
        p.getInventory().clear();          // main inventory + armor + offhand
        p.getEnderChestInventory().clear();// ender chest
        p.setExperienceLevel(0);
        p.setExperiencePoints(0);
        p.clearStatusEffects();
        p.setHealth(p.getMaxHealth());
        p.getHungerManager().setFoodLevel(20);
        p.playerScreenHandler.sendContentUpdates();
    }

}
