# Last Cast — Fabric 1.21.11

This is a Fabric server-side mod project built from the original `LastCastMod.java` source, configured for Minecraft Java 1.21.11.

## Commands
- `/lastcast give` — gives the player a ready-to-use Last Cast fishing rod.
- `/lastcast` — arms the fishing rod held in the main hand (or offhand if needed).
- `/lastcast grace <seconds>` — sets the grace period from 0 to 60 seconds.
- `/lastcast stop` — stops all active traps.

Commands have no OP permission requirement in this source. The warning title `DON'T MOVE!` is not used.

## Build
Requires Java 21 and Gradle. From this folder run:

```bash
gradle build
```

The compiled mod jar will be in `build/libs/`.

Install the resulting `lastcast-1.0.0.jar` on a Minecraft Java 1.21.11 Fabric server with Fabric API installed.
